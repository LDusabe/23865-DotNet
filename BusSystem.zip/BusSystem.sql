USE [master]
GO
/****** Object:  Database [BusSystem]    Script Date: 24/11/2023 21:57:03 ******/
CREATE DATABASE [BusSystem]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'BusSystem', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL12.SQLEXPRESS\MSSQL\DATA\BusSystem.mdf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'BusSystem_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL12.SQLEXPRESS\MSSQL\DATA\BusSystem_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
ALTER DATABASE [BusSystem] SET COMPATIBILITY_LEVEL = 120
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [BusSystem].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [BusSystem] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [BusSystem] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [BusSystem] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [BusSystem] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [BusSystem] SET ARITHABORT OFF 
GO
ALTER DATABASE [BusSystem] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [BusSystem] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [BusSystem] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [BusSystem] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [BusSystem] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [BusSystem] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [BusSystem] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [BusSystem] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [BusSystem] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [BusSystem] SET  DISABLE_BROKER 
GO
ALTER DATABASE [BusSystem] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [BusSystem] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [BusSystem] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [BusSystem] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [BusSystem] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [BusSystem] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [BusSystem] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [BusSystem] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [BusSystem] SET  MULTI_USER 
GO
ALTER DATABASE [BusSystem] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [BusSystem] SET DB_CHAINING OFF 
GO
ALTER DATABASE [BusSystem] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [BusSystem] SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO
ALTER DATABASE [BusSystem] SET DELAYED_DURABILITY = DISABLED 
GO
USE [BusSystem]
GO
/****** Object:  Table [dbo].[Client_rides]    Script Date: 24/11/2023 21:57:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Client_rides](
	[id] [int] NOT NULL,
	[trip_id] [int] NULL,
	[user_id] [int] NULL,
	[payment_status] [nvarchar](50) NULL,
	[checkin] [nvarchar](50) NULL,
	[tripdate] [date] NULL,
 CONSTRAINT [PK_Client_rides] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Driver]    Script Date: 24/11/2023 21:57:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Driver](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[firstname] [nvarchar](50) NULL,
	[lastname] [nvarchar](50) NULL,
	[D_category] [nvarchar](50) NULL,
	[Phone] [nvarchar](50) NULL,
	[dob] [nvarchar](50) NULL,
 CONSTRAINT [PK_Driver] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[stops]    Script Date: 24/11/2023 21:57:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[stops](
	[id] [int] NULL,
	[stops_destination] [nvarchar](50) NULL,
	[trip_id] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Trip]    Script Date: 24/11/2023 21:57:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trip](
	[id] [int] NOT NULL,
	[driver_id] [int] NULL,
	[vehicle_id] [int] NULL,
	[init_destination] [nvarchar](50) NULL,
	[final_destination] [nvarchar](50) NULL,
	[price] [nvarchar](50) NULL,
	[trip_date] [nvarchar](50) NULL,
 CONSTRAINT [PK_Trip] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[User]    Script Date: 24/11/2023 21:57:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[firstname] [nvarchar](50) NULL,
	[lastname] [nvarchar](50) NULL,
	[gender] [nvarchar](50) NULL,
	[email] [nvarchar](50) NULL,
	[role] [nvarchar](50) NULL,
	[dob] [nvarchar](50) NULL,
 CONSTRAINT [PK_User_1] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Vehicle]    Script Date: 24/11/2023 21:57:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Vehicle](
	[Vehicle_id] [int] NOT NULL,
	[Vehicle_name] [nvarchar](50) NULL,
	[Driver_id] [int] NULL,
	[vehicle_types] [nvarchar](50) NULL,
	[seats] [int] NULL,
 CONSTRAINT [PK_Vehicle] PRIMARY KEY CLUSTERED 
(
	[Vehicle_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[Client_rides] ADD  CONSTRAINT [DF_Client_rides_payment_status]  DEFAULT (N'PENDING') FOR [payment_status]
GO
ALTER TABLE [dbo].[Client_rides] ADD  CONSTRAINT [DF_Client_rides_checkin]  DEFAULT (N'NO') FOR [checkin]
GO
ALTER TABLE [dbo].[Client_rides]  WITH CHECK ADD  CONSTRAINT [FK_Client_rides_Trip] FOREIGN KEY([trip_id])
REFERENCES [dbo].[Trip] ([id])
GO
ALTER TABLE [dbo].[Client_rides] CHECK CONSTRAINT [FK_Client_rides_Trip]
GO
ALTER TABLE [dbo].[Client_rides]  WITH CHECK ADD  CONSTRAINT [FK_Client_rides_User] FOREIGN KEY([user_id])
REFERENCES [dbo].[User] ([id])
GO
ALTER TABLE [dbo].[Client_rides] CHECK CONSTRAINT [FK_Client_rides_User]
GO
ALTER TABLE [dbo].[stops]  WITH CHECK ADD  CONSTRAINT [FK_stops_Trip] FOREIGN KEY([trip_id])
REFERENCES [dbo].[Trip] ([id])
GO
ALTER TABLE [dbo].[stops] CHECK CONSTRAINT [FK_stops_Trip]
GO
ALTER TABLE [dbo].[Trip]  WITH CHECK ADD  CONSTRAINT [FK_Trip_Driver] FOREIGN KEY([driver_id])
REFERENCES [dbo].[Driver] ([id])
GO
ALTER TABLE [dbo].[Trip] CHECK CONSTRAINT [FK_Trip_Driver]
GO
ALTER TABLE [dbo].[Trip]  WITH CHECK ADD  CONSTRAINT [FK_Trip_Vehicle] FOREIGN KEY([vehicle_id])
REFERENCES [dbo].[Vehicle] ([Vehicle_id])
GO
ALTER TABLE [dbo].[Trip] CHECK CONSTRAINT [FK_Trip_Vehicle]
GO
ALTER TABLE [dbo].[Vehicle]  WITH CHECK ADD  CONSTRAINT [FK_Vehicle_Driver] FOREIGN KEY([Driver_id])
REFERENCES [dbo].[Driver] ([id])
GO
ALTER TABLE [dbo].[Vehicle] CHECK CONSTRAINT [FK_Vehicle_Driver]
GO
USE [master]
GO
ALTER DATABASE [BusSystem] SET  READ_WRITE 
GO
